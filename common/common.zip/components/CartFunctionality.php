<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of SetValues
 *
 * @author user
 */

namespace common\components;

use Yii;
use yii\base\Component;
use common\models\Cart;
use common\models\WishList;

class CartFunctionality extends Component {
    /*
     * This function check if the user is guest
     * if guest return session_id otherwise return user_id
     */

    public function UserCheck() {
        if (isset(Yii::$app->user->identity->id)) {
            $user_id = Yii::$app->user->identity->id;
            $condition = ['user_id' => $user_id];
        } else {
            if (!isset(Yii::$app->session['temp_user'])) {
                $milliseconds = round(microtime(true) * 1000);
                Yii::$app->session['temp_user'] = $milliseconds;
            }
            $sessonid = Yii::$app->session['temp_user'];
            $condition = ['session_id' => $sessonid];
        }
        return $condition;
    }

    /*
     * This function add product to cart
     * parameeter @product_id,@user_id,@session_id and @qty
     */

    public function AddToCart($user_id, $temp_session, $product_id, $qty) {
        $model = new Cart();
        $model->user_id = $user_id;
        $model->session_id = $temp_session;
        $model->product_id = $product_id;
        $model->quantity = $qty;
        $model->date = date('Y-m-d H:i:s');
        if ($model->save()) {
            return TRUE;
        }
    }

    /*
     * This function add product to wishlist
     * parameeter @product_id
     * Only add to tha wishlist when the user loged in
     */

    public function AddToWishlist($product_id) {
        $flag = 0;
        if (isset(Yii::$app->user->identity->id)) {
            $model = WishList::find()->where(['product' => $product_id, 'user_id' => Yii::$app->user->identity->id])->one();
            if (empty($model)) {
                $model = new WishList();
                $model->user_id = Yii::$app->user->identity->id;
                $model->product = $product_id;
                $model->date = date('Y-m-d');
            } else {
                $model->date = date('Y-m-d');
            }
            if ($model->save()) {
                $flag = 1;
            } else {
                $flag = 3;
            }
        } else {
            $flag = 2;
        }
        return $flag;
    }

}

<?php

$ip = $_SERVER['SERVER_ADDR'];
return array(
    'merchant_email' => 'daniel@epitome.ae',
    'secret_key' => 'rYgkM2ZcHhmF9emjV4bKri6bNbOn3yKvx0Pj2PwJ7Soh7LA2QLNh4TtR5ie8RZEoZtH2jeLq7aHeVihM4448Xx02QfbHeQ5ekNgD',
    'site_url' => "http://perfumedunia.com/",
    'return_url' => "http://perfumedunia.com/payment-response.php",
    'ip_merchant' => $ip,
    'cms_with_version' => "VT_PayTabs 0.1.0"
);
?>
<?php

use common\components\ProductLinksWidget;
?>

<?= ProductLinksWidget::widget(['id' => $model->id]) ?>





